﻿import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Livro } from '../../model/Livro';
import { InfoLivroPage } from '../info-livro/info-livro';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public livros: Livro[];

  constructor(public navCtrl: NavController) {
    this.livros = [
      { nome: "Construindo uma API Node.js", autor: "nodejs", img: "../../assets/imgs/livro1.jpg" }   ];
  }

  goToInfoPage(livro: Livro) {
    this.navCtrl.push(InfoLivroPage, { livroSelecionado: livro });
  }

}
