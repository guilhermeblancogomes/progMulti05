export interface Livro { 
    nome: string; 
    autor: string;
    img: string;
}
